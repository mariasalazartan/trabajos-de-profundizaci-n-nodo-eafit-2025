import React from 'react';
import Calculadora from './components/Calculadora';
import './App.css';

function App() {
  return (
    <div className="App">
      <Calculadora />
    </div>
  );
}

export default App;
