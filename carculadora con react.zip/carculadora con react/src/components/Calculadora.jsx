import React, { useState } from 'react';

function Calculadora() {
  const [numero1, setNumero1] = useState('');
  const [numero2, setNumero2] = useState('');
  const [resultado, setResultado] = useState(null);
  const [operacion, setOperacion] = useState('');

  const handleOperacion = () => {
    const n1 = parseFloat(numero1);
    const n2 = numero2 === '' ? 0 : parseFloat(numero2);

    if (isNaN(n1) || (numero2 !== '' && isNaN(n2))) {
      alert("Por favor ingrese números válidos.");
      return;
    }

    let res;

    switch (operacion) {
      case 'suma':
        res = n1 + n2;
        break;
      case 'resta':
        res = n1 - n2;
        break;
      case 'multiplicacion':
        res = n1 * n2;
        break;
      case 'division':
        if (n2 === 0) {
          alert("Error: no se puede dividir por cero.");
          return;
        }
        res = n1 / n2;
        break;
      case 'raiz':
        res = Math.sqrt(n1);
        break;
      case 'cuadrado':
        res = Math.pow(n1, 2);
        break;
      case 'logaritmo':
        const base = parseFloat(prompt("Introduce la base del logaritmo:"));
        if (base <= 0 || base === 1 || isNaN(base)) {
          alert("La base debe ser mayor que 0 y distinta de 1.");
          return;
        }
        res = Math.log(n1) / Math.log(base);
        break;
      case 'valorAbsoluto':
        res = Math.abs(n1);
        break;
      default:
        alert("Operación no válida.");
        return;
    }

    setResultado(res);
  };

  return (
    <div className="calculadora">
      <h1>Calculadora Avanzada</h1>
      <div>
        <input
          type="number"
          value={numero1}
          onChange={(e) => setNumero1(e.target.value)}
          placeholder="Introduce el primer número"
        />
      </div>
      <div>
        <input
          type="number"
          value={numero2}
          onChange={(e) => setNumero2(e.target.value)}
          placeholder="Introduce el segundo número (opcional)"
        />
      </div>
      <div>
        <select onChange={(e) => setOperacion(e.target.value)}>
          <option value="suma">Suma</option>
          <option value="resta">Resta</option>
          <option value="multiplicacion">Multiplicación</option>
          <option value="division">División</option>
          <option value="raiz">Raíz Cuadrada</option>
          <option value="cuadrado">Elevar al cuadrado</option>
          <option value="logaritmo">Logaritmo</option>
          <option value="valorAbsoluto">Valor Absoluto</option>
        </select>
      </div>
      <button onClick={handleOperacion}>Calcular</button>

      {resultado !== null && (
        <div>
          <h2>Resultado: {resultado}</h2>
        </div>
      )}
    </div>
  );
}

export default Calculadora;
