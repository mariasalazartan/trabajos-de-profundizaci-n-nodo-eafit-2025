import React from "react";
import PokemonList from "./components/PokemonList";

const App = () => {
    return (
        <div 
            className="min-h-screen bg-cover bg-center flex flex-col items-center" 
            style={{ 
                backgroundImage: "url('/fondo.jpg')",  
                backgroundSize: "cover",
                backgroundRepeat: "no-repeat",
                backgroundAttachment: "fixed",
                backgroundPosition: "center top", // Ajuste opcional
            }}
        >
            <div className="w-full h-full flex flex-col items-center">
                <div className=" px-6 py-2 rounded-lg shadow-md">
                    <h1 className="text-black text-4xl font-bold drop-shadow-lg">Pokédex</h1>
                </div>
                <PokemonList />
            </div>
        </div>
    );
};

export default App;
