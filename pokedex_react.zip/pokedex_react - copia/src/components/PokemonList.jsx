import React, { useEffect, useState } from "react";
import PokemonCard from "./PokemonCard";

const PokemonList = () => {
    const [pokemonList, setPokemonList] = useState([]);
    const [filteredPokemon, setFilteredPokemon] = useState([]);

    useEffect(() => {
        const fetchPokemon = async () => {
            try {
                const promises = [];
                for (let i = 1; i <= 151; i++) {
                    promises.push(fetch(`https://pokeapi.co/api/v2/pokemon/${i}`).then(res => res.json()));
                }
                const allPokemon = await Promise.all(promises);
                setPokemonList(allPokemon);
                setFilteredPokemon(allPokemon);
            } catch (error) {
                console.error("Error al obtener Pokémon:", error);
            }
        };

        fetchPokemon();
    }, []);

    const filterPokemon = (search) => {
        setFilteredPokemon(pokemonList.filter(pokemon => pokemon.name.includes(search.toLowerCase())));
    };

    return (
        <div>
            <input
                type="text"
                placeholder="Buscar Pokémon..."
                className="w-full px-4 py-2 border rounded-lg text-black"
                onChange={(e) => filterPokemon(e.target.value)}
            />
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
                {filteredPokemon.map(pokemon => (
                    <PokemonCard key={pokemon.id} pokemon={pokemon} />
                ))}
            </div>
        </div>
    );
};

export default PokemonList;
