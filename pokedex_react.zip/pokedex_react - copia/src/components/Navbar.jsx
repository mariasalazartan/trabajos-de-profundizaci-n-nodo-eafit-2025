// src/components/Navbar.jsx
import React from "react";

const Navbar = () => {
    return (
        <nav className="fixed top-0 left-0 w-full bg-gray-900 text-white py-3 flex justify-center gap-6 z-50 shadow-md">
            <button className="px-4 py-2 hover:bg-gray-700 rounded">Inicio</button>
            <button className="px-4 py-2 hover:bg-gray-700 rounded">Favoritos</button>
            <button className="px-4 py-2 hover:bg-gray-700 rounded">Acerca de</button>
        </nav>
    );
};

export default Navbar;
