import React, { useState } from "react";
import { motion } from "framer-motion";
import typeColors from "../utils/typeColors";

const PokemonCard = ({ pokemon }) => {
    const [flipped, setFlipped] = useState(false);
    const mainType = pokemon.types[0].type.name;
    const cardColor = typeColors[mainType] || "#A8A878";

    return (
        <motion.div 
            className="pokemon-card relative w-64 h-96 p-4 rounded-xl shadow-xl border-4 transition-transform transform perspective-1000"
            style={{ borderColor: cardColor }}
            onClick={() => setFlipped(!flipped)}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <div className="relative w-full h-full rounded-lg transition-transform duration-500 transform text-black" style={{ transformStyle: "preserve-3d", transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)" }}>
                {/* Front Side */}
                <div className="absolute w-full h-full bg-gradient-to-br from-gray-100 to-gray-300 rounded-lg flex flex-col items-center p-4 shadow-lg border-2 text-black" style={{ backfaceVisibility: "hidden", borderColor: cardColor }}>
                    <img
                        src={pokemon.sprites.other["official-artwork"].front_default || pokemon.sprites.front_default}
                        alt={pokemon.name}
                        className="w-56 h-56 object-contain -mt-16 drop-shadow-xl"
                    />
                    <h2 className="text-base font-bold capitalize tracking-wide text-black mt-4 border-b-4 pb-2 w-full text-center" style={{ borderColor: cardColor }}>
                        {pokemon.name}
                    </h2>
                    <div className="mt-3 flex justify-center gap-2">
                        {pokemon.types.map((type) => (
                            <span 
                                key={type.type.name} 
                                className="px-3 py-1 rounded-full border-2 text-xs font-semibold shadow-md text-black"
                                style={{ borderColor: typeColors[type.type.name], backgroundColor: `${typeColors[type.type.name]}60` }}
                            >
                                {type.type.name}
                            </span>
                        ))}
                    </div>
                </div>
                {/* Back Side */}
                <div className="absolute w-full h-full bg-white rounded-lg flex flex-col items-center text-xs text-black p-4 overflow-auto scrollbar-thin" style={{ transform: "rotateY(180deg)", backfaceVisibility: "hidden", borderColor: cardColor, scrollbarColor: `${cardColor} ${cardColor}30` }}>
                    <h2 className="text-sm font-bold capitalize tracking-wide border-b-4 pb-2 w-full text-center" style={{ borderColor: cardColor }}>
                        {pokemon.name}
                    </h2>
                    <p><strong>Peso:</strong> {pokemon.weight / 10} kg</p>
                    <p><strong>Altura:</strong> {pokemon.height / 10} m</p>
                    <p><strong>Experiencia Base:</strong> {pokemon.base_experience}</p>
                    <h3 className="mt-2 font-bold">Estadísticas:</h3>
                    <ul className="text-left list-disc list-inside">
                        {pokemon.stats.map(stat => (
                            <li key={stat.stat.name} className="border-l-4 pl-2" style={{ borderColor: cardColor }}>
                                <strong>{stat.stat.name}:</strong> {stat.base_stat}
                            </li>
                        ))}
                    </ul>
                    <h3 className="mt-2 font-bold">Movimientos:</h3>
                    <ul className="text-left list-disc list-inside">
                        {pokemon.moves.slice(0, 5).map(move => (
                            <li key={move.move.name}>{move.move.name}</li>
                        ))}
                    </ul>
                </div>
            </div>
        </motion.div>
    );
};

export default PokemonCard;
