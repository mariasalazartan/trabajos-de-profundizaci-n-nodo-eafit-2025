import React from "react";

const TaskItem = ({ text, removeTask }) => {
  return (
    <li>
      {text}
      <button onClick={removeTask}>Eliminar</button>
    </li>
  );
};

export default TaskItem;
