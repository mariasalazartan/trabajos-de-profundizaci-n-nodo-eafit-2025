import React, { useState } from "react";

const TaskInput = ({ addTask }) => {
  const [task, setTask] = useState("");

  const handleAddTask = () => {
    addTask(task);
    setTask("");
  };

  return (
    <div>
      <input
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Escribe una tarea..."
      />
      <button onClick={handleAddTask}>Agregar</button>
    </div>
  );
};

export default TaskInput;
