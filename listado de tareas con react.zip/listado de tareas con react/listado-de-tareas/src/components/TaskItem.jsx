import React from "react";

const TaskItem = ({ task, removeTask }) => {
  return (
    <li>
      {task}
      <button className="btnEliminar" onClick={removeTask}>Eliminar</button>
    </li>
  );
};

export default TaskItem;
